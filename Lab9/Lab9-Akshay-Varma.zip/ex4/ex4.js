


fetch('https://api.github.com/emojis')
.then(response => response.json())
.then(users => console.log(users))
.then(users => {
    
})